<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-03 09:48:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 09:48:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 09:48:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-03 09:48:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-03 09:48:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-03 09:52:18 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 09:53:52 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:29:49 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-03 10:29:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:29:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:29:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-03 10:29:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-03 10:29:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-03 10:29:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 10:29:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 10:29:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 10:29:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:29:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:29:50 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-03 10:29:50 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-03 10:29:50 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:32:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-03 10:33:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:33:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 10:36:49 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 10:36:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:39:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:40:20 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 10:41:59 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:45:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 10:46:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:49:33 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 10:50:10 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:51:23 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 10:54:57 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:56:30 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 10:57:07 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 10:57:28 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 10:58:10 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:00:45 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:03:55 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:05:15 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:05:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:07:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:08:32 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:09:52 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:10:38 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:11:30 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:11:51 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:12:36 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:12:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:13:30 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:13:52 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:14:24 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:14:42 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:15:50 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:16:17 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:17:06 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:17:31 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:18:14 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:18:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:19:04 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:19:21 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:19:44 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:20:42 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:21:58 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:22:47 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:24:07 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:24:36 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:25:17 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-03 11:25:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:25:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-03 11:27:30 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:29:03 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:31:29 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:32:15 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:33:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:34:12 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:34:38 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:35:13 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:35:39 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:36:07 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:36:27 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:37:15 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:37:38 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:38:11 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:38:30 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:38:57 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:39:14 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:39:38 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:41:17 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:42:32 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:42:58 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:44:20 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:44:40 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:48:50 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:49:18 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:49:50 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:50:08 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:50:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:50:54 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:51:16 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:51:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:52:15 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:52:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:52:58 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:53:16 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:53:39 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-03 11:53:58 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-03 11:54:20 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
