<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-07 12:51:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-07 12:51:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-07 12:51:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-07 12:51:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-07 12:51:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:51:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-07 12:53:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 12:56:12 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 12:57:05 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 12:57:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 12:58:09 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 12:59:11 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 12:59:32 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:00:04 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:00:22 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:08:59 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:10:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:11:33 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:12:52 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:13:09 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:13:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:13:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:14:25 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:14:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:16:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:16:54 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:17:45 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:18:05 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:18:33 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:19:03 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:20:44 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:22:14 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:22:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:23:02 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:23:21 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:23:46 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:24:08 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:24:41 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:25:14 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:26:14 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-07 13:27:02 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:29:27 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-07 13:47:48 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
