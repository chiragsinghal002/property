<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-15 13:29:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-15 13:29:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:29:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:29:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-15 13:29:34 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-15 13:35:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-15 13:35:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-15 13:35:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:35:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:35:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-15 13:35:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-15 13:35:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:35:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:35:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-15 13:35:05 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-15 13:35:05 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-15 13:35:05 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-15 13:37:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\foodapp\system\core\Loader.php 348
ERROR - 2019-03-15 13:37:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\foodapp\system\core\Loader.php 348
ERROR - 2019-03-15 13:46:25 --> 404 Page Not Found: Auth/sign_up
ERROR - 2019-03-15 13:47:30 --> 404 Page Not Found: Signup/index
ERROR - 2019-03-15 13:50:40 --> 404 Page Not Found: Auth/sign_up
ERROR - 2019-03-15 13:50:57 --> 404 Page Not Found: Signup/index
ERROR - 2019-03-15 13:51:25 --> 404 Page Not Found: Signup/index
ERROR - 2019-03-15 13:52:17 --> 404 Page Not Found: Signup/index
ERROR - 2019-03-15 13:52:23 --> 404 Page Not Found: Signup/index
ERROR - 2019-03-15 13:53:46 --> 404 Page Not Found: Signup/index
