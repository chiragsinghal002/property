<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-17 04:50:37 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-17 04:50:37 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-17 05:16:38 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image051719051638banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 55
ERROR - 2019-05-17 05:16:38 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/php3g4Qkd' to '/home/logodesi/public_html/property/image051719051638banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 55
ERROR - 2019-05-17 05:17:05 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image051719051705banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 55
ERROR - 2019-05-17 05:17:05 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpRg6Qzp' to '/home/logodesi/public_html/property/image051719051705banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 55
ERROR - 2019-05-17 07:36:50 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-17 10:31:51 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-17 10:48:54 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-17 12:16:27 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
