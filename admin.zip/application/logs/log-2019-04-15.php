<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-15 07:32:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 07:32:53 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-15 10:15:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 11:58:43 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-15 11:58:43 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 11:58:43 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-15 11:58:48 --> 404 Page Not Found: Js/dashboard.js
