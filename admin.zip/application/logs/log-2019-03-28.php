<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-28 12:57:46 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:57:46 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 12:57:46 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 12:57:46 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:57:47 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:57:48 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 12:57:48 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 12:57:48 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 12:58:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 12:58:09 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 12:58:09 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 12:58:09 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 12:58:12 --> Query error: Table 'property_dealer.cuisines' doesn't exist - Invalid query: SELECT *
FROM `cuisines`
ORDER BY `cuisines`.`cuisines_id` DESC
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:02:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:02:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:02:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 13:02:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 13:02:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:08:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-28 13:08:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-28 13:08:02 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-28 13:08:02 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-28 13:08:02 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-28 13:55:00 --> 404 Page Not Found: Add/subcuisines
ERROR - 2019-03-28 13:55:02 --> 404 Page Not Found: Add/cuisines
ERROR - 2019-03-28 14:05:05 --> 404 Page Not Found: Add/cuisines
ERROR - 2019-03-28 14:07:15 --> Query error: Table 'property_dealer.cuisines' doesn't exist - Invalid query: SELECT *
FROM `cuisines`
WHERE `cuisines_name` = 'sdgdfh'
ERROR - 2019-03-28 14:14:51 --> Severity: Notice --> Undefined index: cooking_style_name C:\xampp\htdocs\property_dealer\application\views\lists\category.php 38
ERROR - 2019-03-28 14:14:51 --> Severity: Notice --> Undefined index: cooking_status C:\xampp\htdocs\property_dealer\application\views\lists\category.php 40
ERROR - 2019-03-28 14:14:51 --> Severity: Notice --> Undefined index: cooking_style_id C:\xampp\htdocs\property_dealer\application\views\lists\category.php 43
ERROR - 2019-03-28 14:14:51 --> Severity: Notice --> Undefined index: cooking_style_id C:\xampp\htdocs\property_dealer\application\views\lists\category.php 44
ERROR - 2019-03-28 14:20:12 --> 404 Page Not Found: Listing/category
ERROR - 2019-03-28 14:20:26 --> 404 Page Not Found: Listing/category
ERROR - 2019-03-28 14:21:08 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 22
ERROR - 2019-03-28 14:21:08 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 26
ERROR - 2019-03-28 14:21:08 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 37
ERROR - 2019-03-28 14:21:08 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 38
