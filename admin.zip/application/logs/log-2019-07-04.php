<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Vendors/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Vendors/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 11:23:38 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 11:27:44 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 13:04:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-04 13:30:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-04 13:39:44 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 159
ERROR - 2019-07-04 13:39:47 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 159
ERROR - 2019-07-04 13:39:50 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 159
ERROR - 2019-07-04 13:39:58 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 155
ERROR - 2019-07-04 13:40:00 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-04 13:40:02 --> Severity: error --> Exception: syntax error, unexpected '$sql' (T_VARIABLE) /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 155
ERROR - 2019-07-04 13:41:57 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:57 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:57 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:57 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:57 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:58 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:58 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:58 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:58 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:41:58 --> Severity: Notice --> Undefined index: cat_id /var/www/vhosts/property/httpdocs/application/views/lists/dealers.php 103
ERROR - 2019-07-04 13:54:18 --> Severity: Compile Error --> Cannot redeclare Delete::subcategory() /var/www/vhosts/property/httpdocs/application/controllers/Delete.php 39
ERROR - 2019-07-04 13:56:57 --> 404 Page Not Found: Listing/dealer
ERROR - 2019-07-04 14:58:10 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-04 14:58:46 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-04 14:59:21 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-04 14:59:56 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-04 15:02:19 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-04 15:02:43 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-04 15:02:44 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-04 15:21:20 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-04 15:22:38 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-04 15:43:27 --> Severity: Compile Error --> Cannot redeclare Common_model::get_all_categoryfilter() /var/www/vhosts/property/httpdocs/application/models/Common_model.php 137
ERROR - 2019-07-04 15:43:29 --> Severity: Compile Error --> Cannot redeclare Common_model::get_all_categoryfilter() /var/www/vhosts/property/httpdocs/application/models/Common_model.php 137
ERROR - 2019-07-04 15:45:50 --> Severity: Compile Error --> Cannot redeclare Common_model::get_all_categoryfilter() /var/www/vhosts/property/httpdocs/application/models/Common_model.php 137
ERROR - 2019-07-04 15:45:51 --> Severity: Compile Error --> Cannot redeclare Common_model::get_all_categoryfilter() /var/www/vhosts/property/httpdocs/application/models/Common_model.php 137
ERROR - 2019-07-04 15:45:51 --> Severity: Compile Error --> Cannot redeclare Common_model::get_all_categoryfilter() /var/www/vhosts/property/httpdocs/application/models/Common_model.php 137
ERROR - 2019-07-04 15:45:51 --> Severity: Compile Error --> Cannot redeclare Common_model::get_all_categoryfilter() /var/www/vhosts/property/httpdocs/application/models/Common_model.php 137
ERROR - 2019-07-04 15:45:52 --> Severity: Compile Error --> Cannot redeclare Common_model::get_all_categoryfilter() /var/www/vhosts/property/httpdocs/application/models/Common_model.php 137
ERROR - 2019-07-04 17:11:47 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:11:49 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:11:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:11:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:11:51 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:34 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:36 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:37 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:37 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:38 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:38 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:39 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:39 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:39 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:39 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:40 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:41 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:41 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:41 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:42 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:15:51 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:34 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:35 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:36 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:36 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:36 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:36 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:36 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:37 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:38 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:38 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:38 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:38 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:38 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:39 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:47 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:48 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:51 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:54 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:58 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:16:59 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:18 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:19 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:51 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:17:54 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:19:33 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:24 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:25 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:26 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:20:27 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:21:43 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:21:43 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:21:43 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:21:43 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:21:43 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:23:35 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:23:46 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:23:47 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:23:48 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:24:43 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:27:00 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:05 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:07 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:08 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:08 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:08 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:08 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:08 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:08 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:08 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:09 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-04 17:28:10 --> 404 Page Not Found: Listing/fetch.php
