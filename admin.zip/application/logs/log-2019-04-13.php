<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-13 06:51:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-13 06:51:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-13 06:51:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-13 06:51:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-13 06:51:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-13 06:51:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-13 06:51:42 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-13 06:51:42 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-13 06:51:42 --> 404 Page Not Found: Js/dashboard.js
