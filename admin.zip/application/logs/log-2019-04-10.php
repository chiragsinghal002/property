<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-10 09:24:58 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-10 09:25:39 --> 404 Page Not Found: Listing/childsubcategory
ERROR - 2019-04-10 09:26:46 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\subchildcategory.php 8
ERROR - 2019-04-10 09:26:46 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\subchildcategory.php 8
ERROR - 2019-04-10 12:14:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:14:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-10 12:14:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-10 12:14:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-10 12:14:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-10 12:14:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-10 12:14:51 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:14:51 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-10 12:14:51 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:14:51 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:14:51 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-10 12:14:51 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-10 12:14:52 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-10 12:20:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:20:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:20:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-10 12:20:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-10 12:20:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-10 12:20:34 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-10 12:42:35 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 12:51:32 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 12:51:50 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 12:52:01 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 12:53:58 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:03:31 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:04:51 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:09:39 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:12:07 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:17:53 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:18:04 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:18:20 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:19:00 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:19:21 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:19:33 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:31:42 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:32:02 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:32:04 --> Severity: Notice --> Undefined variable: type C:\xampp2\htdocs\property_dealer\application\models\Common_model.php 99
ERROR - 2019-04-10 13:32:04 --> Query error: Unknown column 'cat_status' in 'where clause' - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
WHERE `cat_status` = '1'
AND `property_type` IS NULL
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-04-10 13:35:19 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:35:22 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:36:10 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:36:56 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:36:56 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:37:23 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:37:23 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:37:31 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:37:35 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:37:35 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:37:45 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:37:45 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:37:55 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:37:55 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:47:25 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:47:25 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:52:00 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:52:00 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:56:46 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:56:46 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:58:30 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:58:30 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:58:38 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:58:38 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:59:38 --> Severity: error --> Exception: syntax error, unexpected '{' C:\xampp2\htdocs\property_dealer\application\models\Common_model.php 98
ERROR - 2019-04-10 13:59:57 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:59:57 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 13:59:59 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 13:59:59 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-10 14:00:03 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 14:02:40 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-10 14:02:40 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
