<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-12 07:19:01 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-12 07:19:02 --> 404 Page Not Found: Js/dashboard.js
