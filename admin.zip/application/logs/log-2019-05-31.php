<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-31 05:14:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-31 05:14:54 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-05-31 05:15:27 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-05-31 08:04:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 08:04:30 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-31 08:04:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 08:04:30 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-31 08:04:30 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-31 08:04:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 08:04:30 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 08:04:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 08:04:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 08:04:31 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-31 08:04:31 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-31 08:04:31 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-31 08:05:00 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-05-31 08:09:41 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-05-31 08:11:07 --> 404 Page Not Found: Listing/manage_property57
ERROR - 2019-05-31 08:11:36 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-05-31 08:34:55 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-05-31 09:51:10 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*, `residential_properties`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
JOIN `residential_properties` ON `dealer`.`dealer_id` = `residential_properties`.`dealer_id`
WHERE `residential_properties`.`dealer_id` = '1'
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:53:34 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:55:19 --> Severity: Notice --> Undefined variable: properties /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 98
ERROR - 2019-05-31 09:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 98
ERROR - 2019-05-31 09:55:19 --> Severity: Warning --> include_once(include/footer.php): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 266
ERROR - 2019-05-31 09:55:19 --> Severity: Warning --> include_once(): Failed opening 'include/footer.php' for inclusion (include_path='.:/opt/alt/php70/usr/share/pear') /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 266
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-31 09:55:45 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 88
ERROR - 2019-05-31 09:59:02 --> Severity: Notice --> Undefined variable: properties /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 158
ERROR - 2019-05-31 09:59:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 158
ERROR - 2019-05-31 10:01:57 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 188
ERROR - 2019-05-31 10:01:57 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:01:57 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:02:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 188
ERROR - 2019-05-31 10:02:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:02:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:03:12 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 188
ERROR - 2019-05-31 10:03:12 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:03:12 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:05:23 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 188
ERROR - 2019-05-31 10:05:23 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:05:23 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:06:05 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 188
ERROR - 2019-05-31 10:06:05 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:06:05 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:06:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 188
ERROR - 2019-05-31 10:06:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:06:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:07:35 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:07:35 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:12:34 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:12:34 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:13:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:13:51 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:14:37 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:14:37 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:15:10 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:15:10 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:15:43 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:15:43 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:16:13 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:16:13 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:17:45 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:17:45 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:18:50 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:18:50 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:20:25 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 211
ERROR - 2019-05-31 10:20:25 --> Severity: Notice --> Undefined variable: data /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 221
ERROR - 2019-05-31 10:32:56 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-31 10:33:41 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Edit.php:368) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-31 10:35:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:24 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: property_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:42:57 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:43:53 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:45:12 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:47:55 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:47:55 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:47:55 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 10:47:55 --> Severity: Notice --> Undefined index: plot_size_area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 65
ERROR - 2019-05-31 11:40:09 --> Severity: Notice --> Undefined index: price /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 190
ERROR - 2019-05-31 11:40:09 --> Severity: Notice --> Undefined index: Plot_Area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 200
ERROR - 2019-05-31 11:40:09 --> Severity: Notice --> Undefined index: Plot_Area_Unit /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 200
ERROR - 2019-05-31 11:41:44 --> Severity: Notice --> Undefined index: price /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 191
ERROR - 2019-05-31 11:41:44 --> Severity: Notice --> Undefined index: Plot_Area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 201
ERROR - 2019-05-31 11:41:44 --> Severity: Notice --> Undefined index: Plot_Area_Unit /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 201
ERROR - 2019-05-31 11:43:47 --> Severity: Notice --> Undefined index: price /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 191
ERROR - 2019-05-31 11:44:04 --> Severity: Notice --> Undefined index: price /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 191
ERROR - 2019-05-31 13:12:11 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-31 13:12:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 13:12:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 13:12:12 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-31 13:12:12 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-31 13:12:12 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-31 13:12:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 13:12:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 13:12:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-31 13:12:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 13:12:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-31 13:12:13 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-31 13:12:13 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-31 13:12:13 --> 404 Page Not Found: Js/dashboard.js
