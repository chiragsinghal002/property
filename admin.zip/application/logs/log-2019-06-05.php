<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 05:10:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 05:11:11 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 06:45:35 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 11:57:05 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 11:57:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 11:57:13 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-06-05 11:57:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 11:57:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 11:57:14 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 11:57:34 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 11:59:08 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:03:07 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:08:15 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-06-05 12:08:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 12:08:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 12:08:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-05 12:08:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 12:08:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-05 12:08:17 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-05 12:08:27 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:12:18 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:14:51 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:17:02 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:18:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:18:49 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:20:30 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:22:23 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:23:07 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:24:38 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:25:08 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:26:27 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:28:14 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:29:12 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:29:54 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:30:34 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:32:15 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:33:24 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:34:08 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:34:38 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:35:35 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:37:10 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:38:45 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:39:58 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:41:14 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:41:38 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:42:05 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:43:41 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:44:35 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:45:15 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:45:45 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:46:13 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:50:02 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:51:16 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:51:46 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:52:11 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:53:52 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 12:54:28 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:01:10 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:01:26 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:02:12 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:02:18 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:03:26 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:03:58 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:05:38 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:06:49 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:07:14 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:07:44 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:07:54 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:08:05 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:08:15 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-06-05 13:08:22 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:09:52 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:10:55 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:11:57 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:12:45 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:13:35 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:14:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:14:28 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:15:02 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:16:35 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:18:07 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:19:54 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:21:08 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:22:06 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:23:01 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:24:06 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:24:54 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:25:19 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:25:43 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:26:18 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:27:33 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:28:53 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:29:42 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:31:21 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:32:23 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:33:24 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:34:17 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:34:55 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:35:14 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:35:48 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:36:45 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:37:43 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:38:44 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-05 13:39:30 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
