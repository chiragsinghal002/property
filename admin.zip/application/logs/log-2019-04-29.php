<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-29 11:45:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-29 11:45:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-29 11:45:30 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-29 11:45:30 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-29 11:45:31 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-29 11:45:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-29 11:45:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-29 11:45:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-29 11:45:31 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-29 11:48:36 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-04-29 12:16:27 --> Severity: Notice --> Undefined variable: cuisines /home/logodesi/public_html/projects/property/application/views/edit/property_type.php 26
ERROR - 2019-04-29 12:16:39 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-04-29 12:17:09 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-04-29 12:42:15 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-29 12:42:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-29 12:42:59 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-04-29 12:43:27 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
