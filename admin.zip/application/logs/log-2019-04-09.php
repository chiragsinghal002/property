<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-09 04:19:50 --> Severity: Notice --> Undefined variable: data C:\xampp2\htdocs\property_dealer\application\views\add\subcategory.php 7
ERROR - 2019-04-09 05:12:04 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\xampp2\htdocs\property_dealer\application\models\Common_model.php 20
ERROR - 2019-04-09 05:17:20 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\xampp2\htdocs\property_dealer\application\models\Common_model.php 20
ERROR - 2019-04-09 05:18:42 --> Severity: Notice --> Undefined variable: get_allcategory C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 312
ERROR - 2019-04-09 07:22:16 --> Severity: error --> Exception: syntax error, unexpected '">"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 312
ERROR - 2019-04-09 08:06:54 --> Severity: Notice --> Undefined index: cat_name C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 65
ERROR - 2019-04-09 08:14:36 --> Severity: Notice --> Undefined index: cat_name C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 65
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined variable: data C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 8
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_name C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 40
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_status C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 42
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_id C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 45
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_id C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 46
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_name C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 40
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_status C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 42
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_id C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 45
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_id C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 46
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_name C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 40
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_status C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 42
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_id C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 45
ERROR - 2019-04-09 08:42:54 --> Severity: Notice --> Undefined index: cat_id C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 46
ERROR - 2019-04-09 08:45:46 --> Severity: Notice --> Undefined variable: data C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 8
ERROR - 2019-04-09 08:45:46 --> Severity: Notice --> Undefined variable: all_info C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 32
ERROR - 2019-04-09 08:45:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 32
ERROR - 2019-04-09 08:54:42 --> Severity: Notice --> Undefined variable: data C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 8
ERROR - 2019-04-09 08:54:42 --> Severity: Notice --> Undefined variable: all_info C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 32
ERROR - 2019-04-09 08:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 32
ERROR - 2019-04-09 08:56:33 --> Severity: Notice --> Undefined variable: all_info C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 32
ERROR - 2019-04-09 08:56:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2\htdocs\property_dealer\application\views\lists\subcategory.php 32
ERROR - 2019-04-09 09:40:13 --> Severity: Compile Error --> Cannot redeclare Add::sub_category() C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 308
ERROR - 2019-04-09 09:41:07 --> 404 Page Not Found: Add/childsubcategory
ERROR - 2019-04-09 09:52:52 --> Query error: Unknown column 'cat_status' in 'where clause' - Invalid query: SELECT *
FROM `property_subcategory`
WHERE `cat_status` = '1'
AND `cat_id` = '7'
ORDER BY `cat_id` DESC
ERROR - 2019-04-09 09:52:55 --> Query error: Unknown column 'cat_status' in 'where clause' - Invalid query: SELECT *
FROM `property_subcategory`
WHERE `cat_status` = '1'
AND `cat_id` = '6'
ORDER BY `cat_id` DESC
ERROR - 2019-04-09 09:53:09 --> Query error: Unknown column 'cat_status' in 'where clause' - Invalid query: SELECT *
FROM `property_subcategory`
WHERE `cat_status` = '1'
AND `cat_id` = '7'
ORDER BY `cat_id` DESC
ERROR - 2019-04-09 10:06:30 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\subchildcategory.php 8
ERROR - 2019-04-09 10:21:12 --> 404 Page Not Found: Listing/unit_size
ERROR - 2019-04-09 11:40:13 --> Severity: Notice --> Undefined index: subcat_name C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 362
ERROR - 2019-04-09 11:40:36 --> Severity: Notice --> Undefined index: subcat_name C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 362
ERROR - 2019-04-09 12:12:44 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 121
ERROR - 2019-04-09 12:12:44 --> Query error: Unknown column 'child_subcat_id' in 'field list' - Invalid query: INSERT INTO `property_subchildcategory` (`property_type`, `cat_id`, `subcat_id`, `child_subcat_id`, `unit_size`, `status`) VALUES ('0', '7', '1', '1', '', '1')
ERROR - 2019-04-09 12:14:51 --> Query error: Unknown column 'child_subcat_id' in 'field list' - Invalid query: INSERT INTO `property_subchildcategory` (`property_type`, `cat_id`, `subcat_id`, `child_subcat_id`, `unit_size`, `status`) VALUES ('0', '7', '1', '1', '1,2,3,4', '1')
ERROR - 2019-04-09 12:15:27 --> Severity: error --> Exception: Call to undefined method Common_model::unit_size() C:\xampp2\htdocs\property_dealer\application\controllers\Add.php 126
ERROR - 2019-04-09 12:16:04 --> Query error: Unknown column 'property_type' in 'field list' - Invalid query: INSERT INTO `unit_size` (`property_type`, `cat_id`, `subcat_id`, `child_subcat_id`, `unit_size`, `status`) VALUES ('0', '7', '1', '1', '1,2,3,4', '1')
ERROR - 2019-04-09 12:16:55 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 12:20:09 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 12:20:46 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 12:21:12 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 12:21:29 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 12:21:43 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 12:21:54 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 12:25:50 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 13:19:07 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 14:12:16 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-09 14:12:35 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT *
FROM `property_size`
WHERE `status` = 1
ERROR - 2019-04-09 14:13:14 --> Severity: Notice --> Undefined variable: all_info C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 30
ERROR - 2019-04-09 14:13:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 30
ERROR - 2019-04-09 14:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 30
ERROR - 2019-04-09 14:16:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 30
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:18:13 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 38
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 42
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:20:37 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 46
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:22:47 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:17 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:23:27 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:23:28 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:23:28 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'property_size' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 41
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'size_status' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 45
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:30:41 --> Severity: Warning --> Illegal string offset 'ingredient_id' C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:38:23 --> Severity: Notice --> Undefined index: ingredient_id C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:38:23 --> Severity: Notice --> Undefined index: ingredient_id C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:38:23 --> Severity: Notice --> Undefined index: ingredient_id C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 48
ERROR - 2019-04-09 14:38:23 --> Severity: Notice --> Undefined index: ingredient_id C:\xampp2\htdocs\property_dealer\application\views\lists\size.php 49
ERROR - 2019-04-09 14:39:36 --> 404 Page Not Found: Add/flavour
ERROR - 2019-04-09 14:42:14 --> 404 Page Not Found: Add/flavour
ERROR - 2019-04-09 14:43:10 --> 404 Page Not Found: Add/flavour
ERROR - 2019-04-09 14:43:18 --> Severity: Notice --> Undefined variable: all_info C:\xampp2\htdocs\property_dealer\application\views\lists\bedroom.php 30
ERROR - 2019-04-09 14:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp2\htdocs\property_dealer\application\views\lists\bedroom.php 30
