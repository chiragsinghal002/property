<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-20 04:57:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-20 04:57:25 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-20 04:57:25 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-20 04:57:25 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-20 04:57:25 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-20 04:57:25 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-20 04:57:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-20 04:57:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-20 04:57:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-20 05:17:33 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-20 05:25:37 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-20 05:25:40 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 05:25:43 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-20 06:38:44 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 06:43:34 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-20 08:01:03 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 09:36:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 09:36:40 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 09:39:46 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 09:40:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 09:58:54 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 10:01:44 --> Query error: Unknown column 'property_subchildcategory.subchildcat_id' in 'order clause' - Invalid query: SELECT `property_subchildcategory`.*, `property_category`.`cat_name`, `property_subcategory`.`subcat_name`
FROM `property_subchildcategory`
JOIN `property_category` ON `property_category`.`cat_id` = `property_subchildcategory`.`cat_id`
LEFT JOIN `property_subcategory` ON `property_subchildcategory`.`subcat_id` = `property_subcategory`.`subcat_id`
ORDER BY `property_subchildcategory`.`subchildcat_id` DESC
ERROR - 2019-05-20 10:06:05 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 10:07:03 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-20 10:07:53 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
