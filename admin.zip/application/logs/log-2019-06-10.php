<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-10 04:53:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-10 04:53:07 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-10 04:53:07 --> 404 Page Not Found: Js/dashboard.js
