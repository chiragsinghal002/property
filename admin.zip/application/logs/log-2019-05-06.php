<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-06 07:30:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:30:14 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:30:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:30:28 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:30:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:30:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:30:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:30:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:30:44 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:30:44 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:30:44 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:44 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:30:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:30:45 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:30:45 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:33:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:33:56 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:34:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:35:39 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:35:39 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:35:54 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:35:54 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:36:17 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:36:18 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:36:19 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:37:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/edit/dealers.php 26
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:38:15 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:39:49 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:39:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:39:51 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:39:51 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:39:51 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:40:09 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:41:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:41:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:41:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:41:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:41:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:41:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:41:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:41:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:41:17 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:41:17 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:41:20 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:08 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/edit/dealers.php 26
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:42:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:44:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:44:36 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:47:50 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/edit/dealers.php 26
ERROR - 2019-05-06 07:52:05 --> Query error: Unknown column 'dealer_name' in 'field list' - Invalid query: UPDATE `dealer` SET `dealer_name` = '&lt;div style=', `dealer_email` = 'r@gmail.com', `dealer_phone` = '9876543210', `dealer_status` = '0', `dealer_modifiedat` = '2019-05-06 07:52:05'
WHERE `dealer_id` = '38'
ERROR - 2019-05-06 07:52:14 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/edit/dealers.php 26
ERROR - 2019-05-06 07:53:46 --> Query error: Unknown column 'dealer_name' in 'field list' - Invalid query: UPDATE `dealer` SET `dealer_name` = 'r', `dealer_email` = 'r@gmail.com', `dealer_phone` = '9876543210', `dealer_status` = '0', `dealer_modifiedat` = '2019-05-06 07:53:46'
WHERE `dealer_id` = '38'
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 07:54:35 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:33 --> Severity: Notice --> Undefined variable: ref_type /home/logodesi/public_html/projects/property/application/controllers/Edit.php 298
ERROR - 2019-05-06 08:08:33 --> Severity: Notice --> Undefined variable: downpayment /home/logodesi/public_html/projects/property/application/controllers/Edit.php 299
ERROR - 2019-05-06 08:08:33 --> Severity: Notice --> Undefined variable: timeframe /home/logodesi/public_html/projects/property/application/controllers/Edit.php 300
ERROR - 2019-05-06 08:08:33 --> Severity: Notice --> Undefined variable: agent /home/logodesi/public_html/projects/property/application/controllers/Edit.php 301
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:08:40 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:10:02 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:04 --> Severity: Notice --> Undefined variable: ref_type /home/logodesi/public_html/projects/property/application/controllers/Edit.php 299
ERROR - 2019-05-06 08:13:04 --> Severity: Notice --> Undefined variable: downpayment /home/logodesi/public_html/projects/property/application/controllers/Edit.php 300
ERROR - 2019-05-06 08:13:04 --> Severity: Notice --> Undefined variable: timeframe /home/logodesi/public_html/projects/property/application/controllers/Edit.php 301
ERROR - 2019-05-06 08:13:04 --> Severity: Notice --> Undefined variable: agent /home/logodesi/public_html/projects/property/application/controllers/Edit.php 302
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:13:12 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:16 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:28 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:39 --> Severity: Notice --> Undefined variable: ref_type /home/logodesi/public_html/projects/property/application/controllers/Edit.php 299
ERROR - 2019-05-06 08:15:39 --> Severity: Notice --> Undefined variable: downpayment /home/logodesi/public_html/projects/property/application/controllers/Edit.php 300
ERROR - 2019-05-06 08:15:39 --> Severity: Notice --> Undefined variable: timeframe /home/logodesi/public_html/projects/property/application/controllers/Edit.php 301
ERROR - 2019-05-06 08:15:39 --> Severity: Notice --> Undefined variable: agent /home/logodesi/public_html/projects/property/application/controllers/Edit.php 302
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:15:46 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:24 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:29 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:21:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:22:50 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /home/logodesi/public_html/projects/property/application/controllers/Edit.php 295
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:32 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:23:48 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-06 08:55:57 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
