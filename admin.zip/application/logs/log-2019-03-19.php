<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-19 06:29:27 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 06:29:27 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 06:29:27 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 06:29:27 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 06:29:27 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 06:29:27 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 06:29:27 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 06:29:28 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 06:29:28 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 06:29:28 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 06:29:28 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:43:19 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\foodapp\application\models\Auth_model.php 8
ERROR - 2019-03-19 07:43:19 --> Query error: No database selected - Invalid query: SELECT *
FROM `panel_users`
WHERE `panel_email` IS NULL
AND `panel_status` = '1'
AND `panel_password` = 'bdd4161816afde635b8882177b8ba534'
ERROR - 2019-03-19 07:46:50 --> Query error: No database selected - Invalid query: SELECT *
FROM `panel_users`
WHERE `panel_email` = 'admin@gmail.com'
AND `panel_status` = '1'
AND `panel_password` = 'bdd4161816afde635b8882177b8ba534'
ERROR - 2019-03-19 07:47:34 --> Query error: No database selected - Invalid query: SELECT *
FROM `panel_users`
WHERE `panel_email` = 'admin@gmail.com'
AND `panel_status` = '1'
AND `panel_password` = 'bdd4161816afde635b8882177b8ba534'
ERROR - 2019-03-19 07:49:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:49:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:49:59 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:49:59 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:50:00 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:50:00 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:50:00 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:50:00 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:50:00 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:50:20 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:50:20 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:50:20 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:50:20 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:50:20 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:50:20 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:50:20 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:50:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:51:32 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:51:32 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:51:32 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:51:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:52:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:54:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:55:38 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:55:39 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:55:39 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:55:42 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:55:43 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:56:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:56:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:56:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:56:56 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:57:26 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:57:27 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:57:27 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:57:27 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:57:27 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:57:43 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:58:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:58:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:58:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:58:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:58:13 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:58:13 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:58:13 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 07:58:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 07:58:53 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:04:15 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:04:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:04:59 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:07:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:07:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:07:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:07:35 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:07:35 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:08:35 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:08:45 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:08:47 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:08:47 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:08:47 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:08:47 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:11:28 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:11:28 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:11:28 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:11:28 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:11:28 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:11:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:11:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:11:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:11:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:11:29 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:11:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:11:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:11:38 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:11:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:11:40 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:11:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:11:40 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:12:34 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:12:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:12:36 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:12:36 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:12:36 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:13:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:13:44 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:13:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:13:44 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:13:45 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:13:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:13:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:13:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:13:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:13:58 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:13:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:13:58 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:13:58 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:13:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:13:59 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:13:59 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:14:00 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:14:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:14:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:14:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:14:19 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:14:19 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:14:19 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:14:19 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:14:19 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:14:20 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:14:20 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:14:20 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:14:20 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:19:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:30 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:19:31 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:19:38 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:19:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:40 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:19:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:19:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:19:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:19:56 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:19:56 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:19:56 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:20:57 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:20:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:20:57 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:20:57 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:20:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:20:58 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:21:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:21:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:21:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:21:12 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:21:12 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:21:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:21:12 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:21:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:21:13 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:21:13 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:21:13 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:23:21 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:23:22 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:23:22 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:23:23 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:23:23 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:23:24 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\foodapp\application\controllers\Auth.php 195
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:23:31 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:23:32 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:23:32 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:23:32 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:23:32 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:23:35 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\foodapp\application\controllers\Auth.php 195
ERROR - 2019-03-19 08:24:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:24:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:24:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:24:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:24:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:24:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:24:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:24:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:24:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:24:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:24:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:25:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:31:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:31:42 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-19 08:31:42 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-19 08:31:42 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-19 08:46:29 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\foodapp\system\core\Loader.php 900
ERROR - 2019-03-19 08:46:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\foodapp\system\core\Loader.php 905
ERROR - 2019-03-19 08:46:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\foodapp\system\core\Loader.php 921
ERROR - 2019-03-19 09:01:54 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\foodapp\application\controllers\Add.php 14
ERROR - 2019-03-19 09:01:54 --> Query error: Table 'foodapp.category' doesn't exist - Invalid query: SELECT *
FROM `category`
WHERE `category_name` IS NULL
ERROR - 2019-03-19 09:02:03 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\foodapp\application\controllers\Add.php 14
ERROR - 2019-03-19 09:02:03 --> Query error: Table 'foodapp.category' doesn't exist - Invalid query: SELECT *
FROM `category`
WHERE `category_name` IS NULL
ERROR - 2019-03-19 09:10:31 --> Severity: Notice --> Undefined index: cuisines C:\xampp\htdocs\foodapp\application\controllers\Add.php 14
ERROR - 2019-03-19 09:10:31 --> Severity: Notice --> Undefined index: cuisines C:\xampp\htdocs\foodapp\application\controllers\Add.php 25
ERROR - 2019-03-19 09:11:38 --> 404 Page Not Found: Category/add
ERROR - 2019-03-19 10:43:48 --> Severity: Parsing Error --> syntax error, unexpected 'List' (T_LIST), expecting identifier (T_STRING) C:\xampp\htdocs\foodapp\application\controllers\List.php 4
ERROR - 2019-03-19 10:44:06 --> Severity: Parsing Error --> syntax error, unexpected 'List' (T_LIST), expecting identifier (T_STRING) C:\xampp\htdocs\foodapp\application\controllers\List.php 4
ERROR - 2019-03-19 10:44:10 --> Severity: Parsing Error --> syntax error, unexpected 'List' (T_LIST), expecting identifier (T_STRING) C:\xampp\htdocs\foodapp\application\controllers\List.php 4
ERROR - 2019-03-19 10:46:03 --> Severity: Parsing Error --> syntax error, unexpected 'List' (T_LIST), expecting identifier (T_STRING) C:\xampp\htdocs\foodapp\application\controllers\List.php 4
ERROR - 2019-03-19 10:46:08 --> Severity: Parsing Error --> syntax error, unexpected 'List' (T_LIST), expecting identifier (T_STRING) C:\xampp\htdocs\foodapp\application\controllers\List.php 4
ERROR - 2019-03-19 10:47:30 --> Severity: Parsing Error --> syntax error, unexpected 'list' (T_LIST), expecting identifier (T_STRING) C:\xampp\htdocs\foodapp\application\controllers\List.php 4
ERROR - 2019-03-19 10:48:45 --> 404 Page Not Found: List/index
ERROR - 2019-03-19 11:06:24 --> 404 Page Not Found: Category/add
ERROR - 2019-03-19 11:22:51 --> Severity: Notice --> Undefined index: hotel_id C:\xampp\htdocs\foodapp\application\views\lists\cuisines.php 44
ERROR - 2019-03-19 11:22:51 --> Severity: Notice --> Undefined index: hotel_id C:\xampp\htdocs\foodapp\application\views\lists\cuisines.php 45
ERROR - 2019-03-19 11:22:51 --> Severity: Notice --> Undefined index: hotel_id C:\xampp\htdocs\foodapp\application\views\lists\cuisines.php 44
ERROR - 2019-03-19 11:22:51 --> Severity: Notice --> Undefined index: hotel_id C:\xampp\htdocs\foodapp\application\views\lists\cuisines.php 45
ERROR - 2019-03-19 11:22:51 --> Severity: Notice --> Undefined index: hotel_id C:\xampp\htdocs\foodapp\application\views\lists\cuisines.php 45
ERROR - 2019-03-19 11:28:42 --> Severity: Error --> Class 'MY_Controller' not found C:\xampp\htdocs\foodapp\application\controllers\Edit.php 4
ERROR - 2019-03-19 11:29:04 --> Severity: Error --> Call to undefined method Common_model::get_category_by_id() C:\xampp\htdocs\foodapp\application\controllers\Edit.php 89
ERROR - 2019-03-19 11:41:58 --> 404 Page Not Found: Category/add
ERROR - 2019-03-19 13:13:21 --> Query error: Unknown column 'flavour_name' in 'field list' - Invalid query: INSERT INTO `cuisines` (`flavour_name`, `flavour_status`, `flavour_created_at`, `flavour_modified_at`) VALUES ('sdfsdf', '1', '2019-03-19 13:13:21', '2019-03-19 13:13:21')
ERROR - 2019-03-19 13:15:19 --> Query error: Unknown column 'cuisines_name' in 'where clause' - Invalid query: SELECT *
FROM `flavour`
WHERE `cuisines_name` = 'sdfsdf'
ERROR - 2019-03-19 13:16:44 --> Query error: Unknown column 'cuisines_name' in 'where clause' - Invalid query: SELECT *
FROM `flavour`
WHERE `cuisines_name` = 'sdfsdf'
ERROR - 2019-03-19 13:17:42 --> 404 Page Not Found: Listing/flavour
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 40
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 42
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 45
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 46
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 40
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 42
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 45
ERROR - 2019-03-19 13:22:43 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\flavour.php 46
ERROR - 2019-03-19 13:34:37 --> Query error: Unknown column 'flavour_name' in 'field list' - Invalid query: UPDATE `cuisines` SET `flavour_name` = 'erytryu2', `flavour_status` = '1', `flavour_modified_at` = '2019-03-19 13:34:37'
WHERE `cuisines_id` = '2'
