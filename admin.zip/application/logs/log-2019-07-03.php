<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-03 13:21:34 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-03 13:21:51 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-03 13:21:57 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-03 13:22:57 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-03 13:23:07 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-03 13:27:01 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-03 13:27:03 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-03 15:47:10 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-03 15:54:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 17:33:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 17:33:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-03 17:33:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-03 17:33:09 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-03 17:33:09 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-03 17:33:09 --> 404 Page Not Found: Js/dashboard.js
