<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Vendors/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-27 10:58:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-27 19:00:30 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-27 19:00:30 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-27 19:00:41 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-27 19:05:19 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
