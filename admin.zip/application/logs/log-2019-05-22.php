<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-22 04:43:49 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:43:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:44:00 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:44:00 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:44:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:44:54 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:44:54 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:56:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 04:57:06 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:57:07 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:57:08 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:57:08 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:57:08 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:57:15 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 04:57:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 04:57:17 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:02:04 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:34 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:03:42 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:04:16 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 05:04:24 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Edit.php:368) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:04:29 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:06:58 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:07:11 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:07:11 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:11:03 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:11:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:11:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:11:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:11:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:11:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:11:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:11:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:11:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:11:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:11:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:11:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:16:26 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:16:26 --> Severity: Warning --> session_regenerate_id(): Cannot regenerate session id - headers already sent /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:16:26 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:18:30 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:43) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:18:30 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:18:56 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:39) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:18:56 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:18:56 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:18:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:18:56 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:18:56 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:18:56 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:18:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:18:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:18:57 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:18:57 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:18:57 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:19:39 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:19:39 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:19:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:19:40 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:19:46 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:19:46 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:20:05 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:20:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:20:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:20:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:20:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:20:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:21:16 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:21:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:21:17 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:21:17 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:28:06 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:28:06 --> Severity: Warning --> session_regenerate_id(): Cannot regenerate session id - headers already sent /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:28:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:28:13 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:28:13 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:28:14 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:28:14 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:29:50 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:29:50 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:31:25 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:31:25 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:32:01 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:32:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:32:13 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:32:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:32:14 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:32:14 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:39:04 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:39:04 --> Severity: Warning --> session_regenerate_id(): Cannot regenerate session id - headers already sent /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:39:04 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:39:37 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:23) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:39:37 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:39:37 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:39:37 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:39:37 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:39:37 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:39:37 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:39:38 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:39:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:39:38 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:39:38 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:39:38 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:40:59 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:40:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:40:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:40:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:41:00 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:41:17 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:41:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:41:35 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:41:35 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:41:52 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:41:57 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:42:12 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:42:12 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:42:26 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:42:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:45 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:42:45 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:43:41 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:43:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:43:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:43:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:44:02 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:44:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:44:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:44:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:44:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:44:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:44:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:44:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:44:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:44:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:45:17 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:45:17 --> Severity: Warning --> session_regenerate_id(): Cannot regenerate session id - headers already sent /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:45:17 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:45:29 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:45:29 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:53 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:45:56 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-22 05:51:21 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:51:21 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:51:22 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:55:55 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:55:55 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:55:56 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:56:59 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 05:56:59 --> Severity: Warning --> session_regenerate_id(): Cannot regenerate session id - headers already sent /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 05:56:59 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 06:03:59 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 06:06:51 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-05-22 06:06:51 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-22 06:06:51 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-22 06:08:13 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-05-22 06:08:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-22 06:08:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-22 06:08:14 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-05-22 06:08:14 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-22 06:08:14 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-22 06:08:22 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-05-22 06:08:22 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-22 06:08:22 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-22 06:08:29 --> Severity: Notice --> Undefined variable: type /home/logodesi/public_html/projects/property/application/models/Common_model.php 193
ERROR - 2019-05-22 06:08:29 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-05-22 06:08:37 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-05-22 06:08:37 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-22 06:08:37 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-22 07:18:01 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 20
ERROR - 2019-05-22 07:18:01 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 102
ERROR - 2019-05-22 07:18:01 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 104
ERROR - 2019-05-22 07:18:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 104
ERROR - 2019-05-22 07:18:44 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 106
ERROR - 2019-05-22 07:19:08 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 84
ERROR - 2019-05-22 07:19:08 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 86
ERROR - 2019-05-22 07:19:35 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 86
ERROR - 2019-05-22 07:19:55 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 07:19:55 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 07:52:26 --> Severity: Notice --> Undefined property: Listing::$hotel_model /home/logodesi/public_html/projects/property/application/controllers/Listing.php 14
ERROR - 2019-05-22 07:52:26 --> Severity: error --> Exception: Call to a member function get_all_hotels() on null /home/logodesi/public_html/projects/property/application/controllers/Listing.php 14
ERROR - 2019-05-22 07:52:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-22 07:57:10 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 07:57:15 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 07:58:11 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 07:58:28 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 08:00:29 --> Severity: error --> Exception: syntax error, unexpected 'LIKE' (T_STRING), expecting ')' /home/logodesi/public_html/projects/property/application/models/Common_model.php 102
ERROR - 2019-05-22 08:00:48 --> Severity: error --> Exception: syntax error, unexpected 'LIKE' (T_STRING), expecting ')' /home/logodesi/public_html/projects/property/application/models/Common_model.php 102
ERROR - 2019-05-22 08:02:26 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /home/logodesi/public_html/projects/property/application/models/Common_model.php 103
ERROR - 2019-05-22 08:02:53 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 08:04:19 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 08:04:57 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 08:05:31 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 08:06:22 --> Severity: Warning --> Missing argument 1 for Common_model::get_allcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 16 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 93
ERROR - 2019-05-22 08:42:31 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 08:42:31 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 08:42:31 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 08:42:31 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 08:42:31 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 08:42:31 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:48:03 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:48:03 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:48:03 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:48:03 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:48:03 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:48:03 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:50:10 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:50:10 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:50:10 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:50:10 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:50:10 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:50:10 --> Severity: Notice --> Undefined index: sub /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 09:51:17 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 20
ERROR - 2019-05-22 09:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 20
ERROR - 2019-05-22 09:55:43 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 09:55:43 --> Severity: Notice --> Undefined variable: row /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 24
ERROR - 2019-05-22 09:57:00 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 09:57:00 --> Severity: Notice --> Undefined variable: row /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 24
ERROR - 2019-05-22 09:57:10 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 09:57:10 --> Severity: Notice --> Undefined variable: row /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 24
ERROR - 2019-05-22 09:58:23 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 19
ERROR - 2019-05-22 09:58:23 --> Severity: Notice --> Undefined variable: row /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 24
ERROR - 2019-05-22 10:00:00 --> Severity: Notice --> Undefined variable: row /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 24
ERROR - 2019-05-22 10:13:10 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 22
ERROR - 2019-05-22 10:13:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 22
ERROR - 2019-05-22 10:13:13 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 22
ERROR - 2019-05-22 10:13:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 22
ERROR - 2019-05-22 10:24:47 --> Severity: Warning --> Missing argument 1 for Common_model::get_subcategoryfilter(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 161 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 115
ERROR - 2019-05-22 10:24:47 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 122
ERROR - 2019-05-22 10:24:51 --> Severity: Warning --> Missing argument 1 for Common_model::get_subcategoryfilter(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 161 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 115
ERROR - 2019-05-22 10:24:51 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 122
ERROR - 2019-05-22 10:25:43 --> Severity: Warning --> Missing argument 1 for Common_model::get_subcategoryfilter(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 161 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 115
ERROR - 2019-05-22 10:26:53 --> Severity: Warning --> Missing argument 1 for Common_model::get_subcategoryfilter(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 161 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 115
ERROR - 2019-05-22 10:32:46 --> Severity: Warning --> Missing argument 1 for Common_model::get_subcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 160 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 133
ERROR - 2019-05-22 10:32:59 --> Severity: Warning --> Missing argument 1 for Common_model::get_subcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 160 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 133
ERROR - 2019-05-22 10:33:03 --> Severity: Warning --> Missing argument 1 for Common_model::get_subcategory(), called in /home/logodesi/public_html/projects/property/application/controllers/Listing.php on line 160 and defined /home/logodesi/public_html/projects/property/application/models/Common_model.php 133
ERROR - 2019-05-22 10:46:49 --> Severity: error --> Exception: Function name must be a string /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 10:46:54 --> Severity: error --> Exception: Function name must be a string /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 10:56:01 --> Severity: Notice --> Undefined index: cat_id /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 10:56:01 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 31
ERROR - 2019-05-22 10:56:01 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 32
ERROR - 2019-05-22 10:56:04 --> Severity: Notice --> Undefined index: cat_id /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 10:56:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 31
ERROR - 2019-05-22 10:56:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 32
ERROR - 2019-05-22 10:56:10 --> Severity: Notice --> Undefined index: cat_id /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 10:56:10 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 31
ERROR - 2019-05-22 10:56:10 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 32
ERROR - 2019-05-22 10:58:36 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 31
ERROR - 2019-05-22 10:58:36 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 32
ERROR - 2019-05-22 10:58:55 --> Severity: Notice --> Undefined index: cat_id /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 10:58:55 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 31
ERROR - 2019-05-22 10:58:55 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 32
ERROR - 2019-05-22 11:01:30 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 25
ERROR - 2019-05-22 11:01:57 --> Severity: Notice --> Undefined index: cat_id /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 21
ERROR - 2019-05-22 11:01:57 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 31
ERROR - 2019-05-22 11:01:57 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 32
ERROR - 2019-05-22 11:04:48 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 11:04:48 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 34
ERROR - 2019-05-22 11:04:58 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 11:04:58 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 34
ERROR - 2019-05-22 11:26:32 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 11:27:34 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 11:28:30 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 11:30:04 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 11:30:04 --> Severity: Notice --> Undefined variable: subcategoryfilter /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 19
ERROR - 2019-05-22 11:30:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 19
ERROR - 2019-05-22 11:30:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 32
ERROR - 2019-05-22 11:31:53 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 11:31:53 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 32
ERROR - 2019-05-22 11:32:51 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 11:32:51 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 32
ERROR - 2019-05-22 11:38:15 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 11:38:15 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 44
ERROR - 2019-05-22 11:51:16 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 11:52:09 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 11:53:09 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 11:58:51 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:00:07 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 23
ERROR - 2019-05-22 12:00:07 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 23
ERROR - 2019-05-22 12:00:07 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 23
ERROR - 2019-05-22 12:00:07 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 23
ERROR - 2019-05-22 12:00:07 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 23
ERROR - 2019-05-22 12:00:07 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 23
ERROR - 2019-05-22 12:00:07 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:01:33 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:02:36 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 12:02:36 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:02:36 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:02:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 12:02:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:02:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:02:56 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_id /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 35
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 37
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_id /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 35
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 37
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_id /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 35
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 37
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_id /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 35
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 37
ERROR - 2019-05-22 12:03:09 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:03:19 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 12:03:19 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:03:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:03:19 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:04:00 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 12:04:00 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:04:00 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:05:46 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 12:05:46 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:05:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:05:46 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:05:55 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-22 12:05:55 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 31
ERROR - 2019-05-22 12:05:55 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:08:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:08:28 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:08:31 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:08:41 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 47
ERROR - 2019-05-22 12:10:57 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 51
ERROR - 2019-05-22 12:12:06 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 51
ERROR - 2019-05-22 12:12:14 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 51
ERROR - 2019-05-22 12:12:53 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 51
ERROR - 2019-05-22 12:12:56 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 51
ERROR - 2019-05-22 12:13:12 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 51
ERROR - 2019-05-22 12:13:54 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:13:56 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:14:00 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:14:37 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:14:52 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 51
ERROR - 2019-05-22 12:15:14 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:17:42 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:22:01 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:22:19 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:23:05 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:23:17 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 210
ERROR - 2019-05-22 12:23:17 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 210
ERROR - 2019-05-22 12:29:11 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 215
ERROR - 2019-05-22 12:29:11 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 215
ERROR - 2019-05-22 12:29:15 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:29:17 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:30:21 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 215
ERROR - 2019-05-22 12:30:21 --> Severity: Notice --> Undefined index: subcat_name /home/logodesi/public_html/projects/property/application/models/Common_model.php 215
ERROR - 2019-05-22 12:31:19 --> Query error: Unknown column 'property_subcategory.subchild_name' in 'where clause' - Invalid query: SELECT `property_subchildcategory`.*, `property_category`.`cat_name`, `property_subcategory`.`subcat_name`
FROM `property_subchildcategory`
JOIN `property_category` ON `property_category`.`cat_id` = `property_subchildcategory`.`cat_id`
LEFT JOIN `property_subcategory` ON `property_subchildcategory`.`subcat_id` = `property_subcategory`.`subcat_id`
WHERE `property_subcategory`.`subcat_id` LIKE '%30%' ESCAPE '!'
AND  `property_subcategory`.`subchild_name` LIKE '%Car Parking Space%' ESCAPE '!'
AND  `property_subcategory`.`property_type` LIKE '%0%' ESCAPE '!'
ORDER BY `property_subchildcategory`.`subchild_id` DESC
ERROR - 2019-05-22 12:31:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/application/models/Common_model.php:194) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-22 12:31:48 --> Query error: Unknown column 'property_subcategory.subchild_name' in 'where clause' - Invalid query: SELECT `property_subchildcategory`.*, `property_category`.`cat_name`, `property_subcategory`.`subcat_name`
FROM `property_subchildcategory`
JOIN `property_category` ON `property_category`.`cat_id` = `property_subchildcategory`.`cat_id`
LEFT JOIN `property_subcategory` ON `property_subchildcategory`.`subcat_id` = `property_subcategory`.`subcat_id`
WHERE `property_subcategory`.`subcat_id` LIKE '%30%' ESCAPE '!'
AND  `property_subcategory`.`subchild_name` LIKE '%Car Parking Space%' ESCAPE '!'
AND  `property_subcategory`.`property_type` LIKE '%0%' ESCAPE '!'
ORDER BY `property_subchildcategory`.`subchild_id` DESC
ERROR - 2019-05-22 12:34:09 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:34:15 --> Severity: Warning --> fopen(/tmp/ci_session66252a9b186a7df26896d90752db6d1998117daa): failed to open stream: Disk quota exceeded /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 174
ERROR - 2019-05-22 12:34:15 --> Session: Unable to open file '/tmp/ci_session66252a9b186a7df26896d90752db6d1998117daa'.
ERROR - 2019-05-22 12:34:15 --> Severity: 4096 --> session_regenerate_id(): Failed to create(read) session ID: user (path: /tmp) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 12:38:07 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:40:03 --> Query error: Unknown column 'property_subcategory.subchild_name' in 'where clause' - Invalid query: SELECT `property_subchildcategory`.*, `property_category`.`cat_name`, `property_subcategory`.`subcat_name`
FROM `property_subchildcategory`
JOIN `property_category` ON `property_category`.`cat_id` = `property_subchildcategory`.`cat_id`
LEFT JOIN `property_subcategory` ON `property_subchildcategory`.`subcat_id` = `property_subcategory`.`subcat_id`
WHERE `property_subcategory`.`subchild_name` LIKE '%Car Parking Space%' ESCAPE '!'
ORDER BY `property_subchildcategory`.`subchild_id` DESC
ERROR - 2019-05-22 12:41:47 --> Query error: Unknown column 'property_subcategory.subchild_name' in 'where clause' - Invalid query: SELECT `property_subchildcategory`.*, `property_category`.`cat_name`, `property_subcategory`.`subcat_name`
FROM `property_subchildcategory`
JOIN `property_category` ON `property_category`.`cat_id` = `property_subchildcategory`.`cat_id`
LEFT JOIN `property_subcategory` ON `property_subchildcategory`.`subcat_id` = `property_subcategory`.`subcat_id`
WHERE `property_subcategory`.`subchild_name` LIKE '%Car Parking Space%' ESCAPE '!'
ORDER BY `property_subchildcategory`.`subchild_id` DESC
ERROR - 2019-05-22 12:42:39 --> Query error: Unknown column 'property_subcategory.subchild_name' in 'where clause' - Invalid query: SELECT `property_subchildcategory`.*, `property_category`.`cat_name`, `property_subcategory`.`subcat_name`
FROM `property_subchildcategory`
JOIN `property_category` ON `property_category`.`cat_id` = `property_subchildcategory`.`cat_id`
LEFT JOIN `property_subcategory` ON `property_subchildcategory`.`subcat_id` = `property_subcategory`.`subcat_id`
WHERE `property_subcategory`.`subchild_name` LIKE '%Car Parking Space%' ESCAPE '!'
ORDER BY `property_subchildcategory`.`subchild_id` DESC
ERROR - 2019-05-22 12:44:04 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 12:45:31 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-22 12:47:36 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:47:36 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:47:58 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:47:58 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:57:11 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:25) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 12:57:11 --> Severity: Warning --> session_regenerate_id(): Cannot regenerate session id - headers already sent /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:57:11 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:57:33 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 12:57:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:57:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:57:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:57:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:57:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:57:34 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:58:04 --> Severity: Notice --> Undefined property: Dashboard::$load /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php 12
ERROR - 2019-05-22 12:58:04 --> Severity: error --> Exception: Call to a member function view() on null /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php 12
ERROR - 2019-05-22 12:58:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-22 12:58:15 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:58:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:58:26 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 12:58:27 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 12:58:46 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:06:10 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:07:40 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:08:39 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:09:21 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:10:02 --> Severity: Warning --> fopen(/tmp/ci_session51925c303c93a2612023536e8df1928594e73962): failed to open stream: Disk quota exceeded /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 174
ERROR - 2019-05-22 13:10:02 --> Session: Unable to open file '/tmp/ci_session51925c303c93a2612023536e8df1928594e73962'.
ERROR - 2019-05-22 13:10:02 --> Severity: 4096 --> session_regenerate_id(): Failed to create(read) session ID: user (path: /tmp) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 13:10:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/helpers/url_helper.php 564
ERROR - 2019-05-22 13:26:06 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:26:42 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:27:13 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:28:22 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:29:28 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:30:25 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:31:03 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:31:35 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:32:29 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:33:02 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-22 13:37:05 --> Severity: Warning --> fopen(/tmp/ci_session5078af108713226cd60cff3c6afdb1459e452180): failed to open stream: Disk quota exceeded /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 174
ERROR - 2019-05-22 13:37:05 --> Session: Unable to open file '/tmp/ci_session5078af108713226cd60cff3c6afdb1459e452180'.
ERROR - 2019-05-22 13:37:05 --> Severity: 4096 --> session_regenerate_id(): Failed to create(read) session ID: user (path: /tmp) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 718
ERROR - 2019-05-22 13:37:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/helpers/url_helper.php 564
ERROR - 2019-05-22 13:47:33 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-22 13:47:33 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-22 13:49:32 --> 404 Page Not Found: Pagination_Controller/index
ERROR - 2019-05-22 13:50:01 --> 404 Page Not Found: Pagination_Controller/index
