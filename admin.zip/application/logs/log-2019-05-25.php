<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-25 03:48:11 --> 404 Page Not Found: Js/dashboard.js
