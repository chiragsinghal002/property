<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 05:58:41 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-20 07:16:01 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\cooking_style.php 38
ERROR - 2019-03-20 07:16:01 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\foodapp\application\views\lists\cooking_style.php 40
ERROR - 2019-03-20 07:16:01 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\cooking_style.php 43
ERROR - 2019-03-20 07:16:01 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\cooking_style.php 44
ERROR - 2019-03-20 07:26:03 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\foodapp\application\views\edit\cooking_style.php 22
ERROR - 2019-03-20 07:26:03 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\foodapp\application\views\edit\cooking_style.php 26
ERROR - 2019-03-20 07:26:03 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\foodapp\application\views\edit\cooking_style.php 37
ERROR - 2019-03-20 07:26:03 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\foodapp\application\views\edit\cooking_style.php 38
ERROR - 2019-03-20 08:56:48 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 08:56:48 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 08:56:48 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-20 08:56:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-20 10:38:25 --> Severity: Notice --> Undefined index: cooking_style_name C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 38
ERROR - 2019-03-20 10:38:25 --> Severity: Notice --> Undefined index: cooking_status C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 40
ERROR - 2019-03-20 10:38:25 --> Severity: Notice --> Undefined index: cooking_style_id C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 43
ERROR - 2019-03-20 10:38:25 --> Severity: Notice --> Undefined index: cooking_style_id C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 44
ERROR - 2019-03-20 10:40:38 --> Severity: Notice --> Undefined index: cooking_style_name C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 42
ERROR - 2019-03-20 10:40:38 --> Severity: Notice --> Undefined index: cooking_status C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 44
ERROR - 2019-03-20 10:40:38 --> Severity: Notice --> Undefined index: cooking_style_id C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 47
ERROR - 2019-03-20 10:40:38 --> Severity: Notice --> Undefined index: cooking_style_id C:\xampp\htdocs\foodapp\application\views\lists\restaurants.php 48
ERROR - 2019-03-20 11:19:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 11:19:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 11:19:40 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-20 11:19:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-20 11:19:40 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-20 11:19:40 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 11:19:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 11:19:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 11:19:44 --> 404 Page Not Found: Dropdown/index
ERROR - 2019-03-20 11:26:49 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\controllers\Dropdowns.php 13
ERROR - 2019-03-20 11:27:09 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\controllers\Dropdowns.php 13
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:29:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:31:13 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:31:40 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:32:42 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:32:42 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:32:42 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:32:42 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:32:42 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:32:42 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:34:33 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:34:33 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:34:33 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:34:33 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:34:33 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:34:33 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 23
ERROR - 2019-03-20 11:35:17 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 25
ERROR - 2019-03-20 11:35:17 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 25
ERROR - 2019-03-20 11:35:17 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 25
ERROR - 2019-03-20 11:35:17 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 25
ERROR - 2019-03-20 11:35:17 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 25
ERROR - 2019-03-20 11:35:17 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\dependent_dropdown.php 25
ERROR - 2019-03-20 11:35:42 --> 404 Page Not Found: Dependent-dropdown/ajax
ERROR - 2019-03-20 11:35:52 --> 404 Page Not Found: Dependent-dropdown/ajax
ERROR - 2019-03-20 11:37:54 --> 404 Page Not Found: Dependent-dropdown/ajax
ERROR - 2019-03-20 11:38:24 --> 404 Page Not Found: Dependent-dropdown/ajax
ERROR - 2019-03-20 11:38:27 --> 404 Page Not Found: Dependent-dropdown/ajax
ERROR - 2019-03-20 11:40:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 11:40:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 11:40:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-20 11:40:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-20 11:40:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 11:40:50 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-20 11:40:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 11:40:50 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-20 11:40:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 11:40:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-20 11:40:51 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-20 11:40:51 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-20 11:40:51 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-20 12:08:07 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 27
ERROR - 2019-03-20 12:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 27
ERROR - 2019-03-20 12:08:29 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 27
ERROR - 2019-03-20 12:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 27
ERROR - 2019-03-20 12:09:40 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 28
ERROR - 2019-03-20 12:09:40 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 28
ERROR - 2019-03-20 12:09:40 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 28
ERROR - 2019-03-20 12:09:40 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 28
ERROR - 2019-03-20 12:09:40 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 28
ERROR - 2019-03-20 12:09:40 --> Severity: Notice --> Undefined index: cuisine_id C:\xampp\htdocs\foodapp\application\views\add\subcuisines.php 28
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 39
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 44
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 45
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 39
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 44
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 45
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 39
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 44
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 45
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 39
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 44
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 45
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_name C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 39
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 44
ERROR - 2019-03-20 12:13:24 --> Severity: Notice --> Undefined index: cuisines_id C:\xampp\htdocs\foodapp\application\views\lists\subcuisines.php 45
ERROR - 2019-03-20 13:32:02 --> Severity: Notice --> Undefined index: flavour_name C:\xampp\htdocs\foodapp\application\views\lists\spice.php 36
ERROR - 2019-03-20 13:32:02 --> Severity: Notice --> Undefined index: flavour_status C:\xampp\htdocs\foodapp\application\views\lists\spice.php 38
ERROR - 2019-03-20 13:32:02 --> Severity: Notice --> Undefined index: flavour_id C:\xampp\htdocs\foodapp\application\views\lists\spice.php 41
ERROR - 2019-03-20 13:32:02 --> Severity: Notice --> Undefined index: flavour_id C:\xampp\htdocs\foodapp\application\views\lists\spice.php 42
