<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-29 07:59:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-29 07:59:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Images/faces
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Vendors/js
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-03-29 07:59:40 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-03-29 07:59:59 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 22
ERROR - 2019-03-29 07:59:59 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 26
ERROR - 2019-03-29 07:59:59 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 37
ERROR - 2019-03-29 07:59:59 --> Severity: Notice --> Undefined variable: cooking C:\xampp\htdocs\property_dealer\application\views\edit\category.php 38
ERROR - 2019-03-29 08:09:14 --> Query error: Table 'property_dealer.cuisines' doesn't exist - Invalid query: SELECT *
FROM `property_type`
JOIN `cuisines` ON `cuisines`.`cuisines_id` = `subcuisines`.`cuisine_id`
ORDER BY `subcuisines`.`subcuisine_id` DESC
ERROR - 2019-03-29 08:09:20 --> Severity: Error --> Call to undefined method Common_model::get_allcuisines() C:\xampp\htdocs\property_dealer\application\controllers\Add.php 60
ERROR - 2019-03-29 08:27:54 --> Query error: Table 'property_dealer.cuisines' doesn't exist - Invalid query: SELECT *
FROM `property_type`
JOIN `cuisines` ON `cuisines`.`cuisines_id` = `subcuisines`.`cuisine_id`
ORDER BY `subcuisines`.`subcuisine_id` DESC
ERROR - 2019-03-29 08:30:01 --> Severity: Error --> Call to undefined method Common_model::get_subcuisinesbyname() C:\xampp\htdocs\property_dealer\application\controllers\Add.php 63
ERROR - 2019-03-29 08:31:13 --> Query error: Table 'property_dealer.cuisines' doesn't exist - Invalid query: SELECT *
FROM `property_type`
JOIN `cuisines` ON `cuisines`.`cuisines_id` = `subcuisines`.`cuisine_id`
ORDER BY `subcuisines`.`subcuisine_id` DESC
ERROR - 2019-03-29 08:35:45 --> Query error: Table 'property_dealer.cuisines' doesn't exist - Invalid query: SELECT *
FROM `property_type`
JOIN `cuisines` ON `cuisines`.`cuisines_id` = `subcuisines`.`cuisine_id`
ORDER BY `subcuisines`.`subcuisine_id` DESC
ERROR - 2019-03-29 08:42:55 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 22
ERROR - 2019-03-29 08:42:55 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 08:42:55 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 37
ERROR - 2019-03-29 08:42:55 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 38
ERROR - 2019-03-29 08:55:15 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 22
ERROR - 2019-03-29 08:55:15 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 08:55:15 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 37
ERROR - 2019-03-29 08:55:15 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 38
ERROR - 2019-03-29 08:58:25 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 08:58:25 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 37
ERROR - 2019-03-29 08:58:25 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 38
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 31
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 32
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 33
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 34
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 35
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 59
ERROR - 2019-03-29 09:02:46 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 60
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 31
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 32
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 33
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 34
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 35
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 59
ERROR - 2019-03-29 09:04:03 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 60
ERROR - 2019-03-29 09:04:18 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 09:04:18 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 31
ERROR - 2019-03-29 09:04:18 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 32
ERROR - 2019-03-29 09:04:18 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 33
ERROR - 2019-03-29 09:04:18 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 34
ERROR - 2019-03-29 09:04:18 --> Severity: Notice --> Undefined variable: hotel C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 35
ERROR - 2019-03-29 09:08:51 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 09:09:17 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 09:09:27 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 09:09:32 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 09:13:52 --> Severity: Notice --> Undefined variable: msg C:\xampp\htdocs\property_dealer\application\views\add\property_type.php 14
ERROR - 2019-03-29 10:45:43 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 10:47:35 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 11:11:45 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 11:11:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 'Admin'
ORDER BY `dealer`.`dealer_id` DESC' at line 3 - Invalid query: SELECT *
FROM `dealer`
WHERE dealer.dealer_type ! 'Admin'
ORDER BY `dealer`.`dealer_id` DESC
ERROR - 2019-03-29 11:13:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 'Admin'
ORDER BY `dealer_id` DESC' at line 3 - Invalid query: SELECT *
FROM `dealer`
WHERE dealer_type ! 'Admin'
ORDER BY `dealer_id` DESC
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:14:08 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:17:10 --> Severity: Notice --> Undefined variable: where C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:17:10 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:18:12 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:18:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 'Admin'
ORDER BY `dealer_id` DESC' at line 3 - Invalid query: SELECT *
FROM `dealer`
WHERE dealer_type ! 'Admin'
ORDER BY `dealer_id` DESC
ERROR - 2019-03-29 11:22:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 'Admin'' at line 3 - Invalid query: SELECT *
FROM `dealer`
WHERE dealer_type ! 'Admin'
ERROR - 2019-03-29 11:22:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 'Admin'
ORDER BY `dealer_id` DESC' at line 3 - Invalid query: SELECT *
FROM `dealer`
WHERE dealer_type ! 'Admin'
ORDER BY `dealer_id` DESC
ERROR - 2019-03-29 11:25:23 --> Severity: Parsing Error --> syntax error, unexpected '>' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:27:37 --> Severity: Notice --> Undefined variable: where C:\xampp\htdocs\property_dealer\application\models\Common_model.php 116
ERROR - 2019-03-29 11:27:37 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\property_dealer\application\models\Common_model.php 116
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:27:59 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:31:13 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:31:59 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:32:01 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:32:10 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:32:13 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:32:15 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:32:20 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\property_dealer\application\models\Common_model.php 108
ERROR - 2019-03-29 11:32:34 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\property_type.php 26
ERROR - 2019-03-29 11:32:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 'Admin'
ORDER BY `dealer_id` DESC' at line 3 - Invalid query: SELECT *
FROM `dealer`
WHERE dealer_type ! 'Admin'
ORDER BY `dealer_id` DESC
ERROR - 2019-03-29 11:33:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\property_dealer\application\models\Common_model.php 112
ERROR - 2019-03-29 11:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 32
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:33:56 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:38:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `dealer_type` NOT IN(SELECT * FROM dealer WHERE dealer_type=Admin)
ORDER B' at line 2 - Invalid query: SELECT *
WHERE `dealer_type` NOT IN(SELECT * FROM dealer WHERE dealer_type=Admin)
ORDER BY `dealer_id` DESC
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:38:55 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 11:42:22 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\property_dealer\application\models\Common_model.php 110
ERROR - 2019-03-29 11:44:08 --> Severity: Notice --> Undefined index: cat_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 41
ERROR - 2019-03-29 11:44:08 --> Severity: Notice --> Undefined index: type_name C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 43
ERROR - 2019-03-29 11:44:08 --> Severity: Notice --> Undefined index: type_status C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 45
ERROR - 2019-03-29 11:44:08 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 48
ERROR - 2019-03-29 11:44:08 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\lists\dealers.php 49
ERROR - 2019-03-29 12:00:06 --> 404 Page Not Found: Edit/dealers
ERROR - 2019-03-29 12:03:49 --> 404 Page Not Found: Listing/price_range
ERROR - 2019-03-29 12:43:06 --> Severity: Notice --> Undefined variable: property_type C:\xampp\htdocs\property_dealer\application\views\edit\dealers.php 22
ERROR - 2019-03-29 12:43:06 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\dealers.php 26
ERROR - 2019-03-29 12:43:06 --> Severity: Notice --> Undefined variable: property_type C:\xampp\htdocs\property_dealer\application\views\edit\dealers.php 37
ERROR - 2019-03-29 12:43:06 --> Severity: Notice --> Undefined variable: cuisines C:\xampp\htdocs\property_dealer\application\views\edit\dealers.php 47
ERROR - 2019-03-29 12:43:06 --> Severity: Notice --> Undefined variable: property_type C:\xampp\htdocs\property_dealer\application\views\edit\dealers.php 58
ERROR - 2019-03-29 12:43:06 --> Severity: Notice --> Undefined variable: property_type C:\xampp\htdocs\property_dealer\application\views\edit\dealers.php 59
ERROR - 2019-03-29 12:44:08 --> Severity: Notice --> Undefined index: type_id C:\xampp\htdocs\property_dealer\application\views\edit\dealers.php 22
ERROR - 2019-03-29 13:01:05 --> 404 Page Not Found: Listing/price_range
