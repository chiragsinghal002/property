<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-21 07:13:18 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:13:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:13:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:13:23 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:13:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:13:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:13:25 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:13:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:13:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:13:32 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:13:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:13:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:13:41 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:13:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:13:41 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:13:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:13:42 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:22) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:13:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:14:15 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:14:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:14:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:14:42 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:14:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:14:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:14:45 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:14:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:14:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:25:02 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:25:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:25:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 07:25:05 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 07:25:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 07:25:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 08:02:27 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 08:02:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 08:02:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 08:11:32 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 08:11:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 08:11:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 08:18:08 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-21 08:18:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/helpers/url_helper.php 561
ERROR - 2019-05-21 08:18:27 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-21 08:18:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/helpers/url_helper.php 561
ERROR - 2019-05-21 08:18:38 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-21 08:18:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/helpers/url_helper.php 561
ERROR - 2019-05-21 08:18:53 --> Severity: Warning --> mkdir(): Permission denied /home/logodesi/public_html/projects/property/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2019-05-21 08:18:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/core/Common.php 570
ERROR - 2019-05-21 08:18:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: /var/cpanel/php/sessions/ea-php56) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-05-21 08:19:08 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-21 08:19:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/logodesi/public_html/projects/property/system/core/Exceptions.php:271) /home/logodesi/public_html/projects/property/system/helpers/url_helper.php 561
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-21 09:44:47 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-21 09:44:51 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:16:56 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-21 12:16:57 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-21 12:18:03 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-21 12:20:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:25:49 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:25:57 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:28:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:30:09 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:32:29 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:34:04 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:35:54 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:46:13 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:47:59 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:49:45 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:51:55 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:52:49 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:54:07 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:56:40 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 12:57:29 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:00:15 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:02:20 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:03:22 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:04:28 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:05:12 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:06:26 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:07:36 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:08:18 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:09:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:10:34 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:11:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:12:49 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:13:34 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:14:51 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:15:43 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:16:21 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:17:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:18:28 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:19:20 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:20:20 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:21:08 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:22:02 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:23:14 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:23:54 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:24:57 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:25:55 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:26:48 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:27:32 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:28:18 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:29:22 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:30:16 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:30:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:31:18 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:35:28 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:36:39 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:38:25 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:39:25 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:40:16 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:40:57 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:41:44 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:42:25 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:42:58 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:43:33 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-21 13:48:05 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
