<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-25 16:03:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'logodesi_propert'@'localhost' (using password: YES) /var/www/vhosts/property/httpdocs/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-06-25 16:03:52 --> Unable to connect to the database
ERROR - 2019-06-25 16:03:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'logodesi_propert'@'localhost' (using password: YES) /var/www/vhosts/property/httpdocs/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-06-25 16:03:55 --> Unable to connect to the database
ERROR - 2019-06-25 17:00:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'logodesi_propert'@'localhost' (using password: YES) /var/www/vhosts/property/httpdocs/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-06-25 17:00:31 --> Unable to connect to the database
