<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-30 04:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-30 04:58:08 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-30 04:58:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-30 04:58:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-30 04:58:11 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-30 04:58:11 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-30 04:58:11 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-30 04:58:11 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-30 04:58:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-30 04:58:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-30 04:58:12 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-30 04:58:12 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-30 04:58:12 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-30 05:09:02 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-30 05:09:57 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subcategory.php 33
ERROR - 2019-05-30 05:10:58 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-30 05:12:21 --> Query error: Table 'logodesi_property.properties' doesn't exist - Invalid query: SELECT `properties`.*, `dealer`.*
FROM `properties`
JOIN `dealer` ON `properties`.`dealer_id` = `dealer`.`dealer_id`
ORDER BY `properties`.`property_id` DESC
ERROR - 2019-05-30 05:13:24 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-30 05:13:44 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-05-30 05:13:52 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
