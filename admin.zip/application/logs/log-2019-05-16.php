<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-16 12:18:08 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-16 12:18:09 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-16 12:18:10 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-16 12:39:54 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:39:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-16 12:40:15 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-16 13:31:39 --> Severity: Notice --> Undefined variable: i /home/logodesi/public_html/projects/property/application/controllers/Add.php 60
ERROR - 2019-05-16 13:31:39 --> Severity: Notice --> String offset cast occurred /home/logodesi/public_html/projects/property/application/controllers/Add.php 60
ERROR - 2019-05-16 13:31:39 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/image/051619013139i): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:31:39 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpuTqFYm' to '/home/logodesi/public_html/image/051619013139i' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:33:17 --> Severity: Notice --> Undefined variable: i /home/logodesi/public_html/projects/property/application/controllers/Add.php 60
ERROR - 2019-05-16 13:33:17 --> Severity: Notice --> String offset cast occurred /home/logodesi/public_html/projects/property/application/controllers/Add.php 60
ERROR - 2019-05-16 13:33:17 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/image/051619013317b): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:33:17 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/php4dKoM6' to '/home/logodesi/public_html/image/051619013317b' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:33:53 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/image/051619013353banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:33:53 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpgyPUe8' to '/home/logodesi/public_html/image/051619013353banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:35:40 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/image/051619013540banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:35:40 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/php7yeE3h' to '/home/logodesi/public_html/image/051619013540banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:37:02 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image051619013702banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:37:02 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpeQVTcA' to '/home/logodesi/public_html/property/image051619013702banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:38:16 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619013816banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:38:16 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpeRgVG0' to '/home/logodesi/public_html/property/image/051619013816banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:41:39 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619014139banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:41:39 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpupje1K' to '/home/logodesi/public_html/property/image/051619014139banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:45:53 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619014553banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:45:53 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpqV9cLh' to '/home/logodesi/public_html/property/image/051619014553banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:45:57 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619014557banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:45:57 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/php66WTTP' to '/home/logodesi/public_html/property/image/051619014557banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:46:42 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619014642banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:46:42 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/php1tzLDh' to '/home/logodesi/public_html/property/image/051619014642banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:46:57 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619014657banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:46:57 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpMOlQao' to '/home/logodesi/public_html/property/image/051619014657banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:47:04 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619014704banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:47:04 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phps3yL0h' to '/home/logodesi/public_html/property/image/051619014704banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:48:56 --> Severity: Warning --> move_uploaded_file(/property/image/051619014856banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:48:56 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpbLJ4Bt' to '/property/image/051619014856banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:49:19 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619014919banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:49:19 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/php30Sf1o' to '/home/logodesi/public_html/property/image/051619014919banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:54:22 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619015422banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 62
ERROR - 2019-05-16 13:54:22 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phppwwRLO' to '/home/logodesi/public_html/property/image/051619015422banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 62
ERROR - 2019-05-16 13:54:22 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image/051619015422banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 63
ERROR - 2019-05-16 13:54:22 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phppwwRLO' to '/home/logodesi/public_html/property/image/051619015422banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 63
ERROR - 2019-05-16 13:55:44 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-16 13:55:44 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-16 13:55:58 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image051619015558banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:55:58 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpPNefdi' to '/home/logodesi/public_html/property/image051619015558banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:58:48 --> Severity: Notice --> Undefined index: hotel /home/logodesi/public_html/projects/property/application/controllers/Add.php 56
ERROR - 2019-05-16 13:58:48 --> Severity: Notice --> Undefined variable: upload_file /home/logodesi/public_html/projects/property/application/controllers/Add.php 86
ERROR - 2019-05-16 13:58:48 --> Severity: Warning --> implode(): Invalid arguments passed /home/logodesi/public_html/projects/property/application/controllers/Add.php 86
ERROR - 2019-05-16 13:58:48 --> Severity: Notice --> Undefined variable: upload_file /home/logodesi/public_html/projects/property/application/controllers/Add.php 98
ERROR - 2019-05-16 13:59:18 --> Severity: Notice --> Undefined index: cat_name /home/logodesi/public_html/projects/property/application/controllers/Add.php 56
ERROR - 2019-05-16 13:59:18 --> Severity: Notice --> Undefined variable: upload_file /home/logodesi/public_html/projects/property/application/controllers/Add.php 86
ERROR - 2019-05-16 13:59:18 --> Severity: Warning --> implode(): Invalid arguments passed /home/logodesi/public_html/projects/property/application/controllers/Add.php 86
ERROR - 2019-05-16 13:59:18 --> Severity: Notice --> Undefined variable: upload_file /home/logodesi/public_html/projects/property/application/controllers/Add.php 98
ERROR - 2019-05-16 13:59:45 --> Severity: Warning --> move_uploaded_file(/home/logodesi/public_html/property/image051619015945banner 2.jpg): failed to open stream: No such file or directory /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:59:45 --> Severity: Warning --> move_uploaded_file(): Unable to move '/tmp/phpHFpT4C' to '/home/logodesi/public_html/property/image051619015945banner 2.jpg' /home/logodesi/public_html/projects/property/application/controllers/Add.php 61
ERROR - 2019-05-16 13:59:45 --> Severity: Warning --> implode(): Invalid arguments passed /home/logodesi/public_html/projects/property/application/controllers/Add.php 86
