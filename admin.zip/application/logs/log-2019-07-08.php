<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Vendors/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 10:22:42 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-08 10:22:43 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-08 10:22:43 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-08 10:55:09 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 10:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 10:55:09 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:03:47 --> Severity: Notice --> Undefined index: all_info /var/www/vhosts/property/httpdocs/application/controllers/Listing.php 81
ERROR - 2019-07-08 11:03:47 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:03:47 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:03:56 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:03:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:03:57 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:05:51 --> Severity: Notice --> Undefined variable: id /var/www/vhosts/property/httpdocs/application/models/Common_model.php 692
ERROR - 2019-07-08 11:05:51 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:05:52 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:06:57 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:06:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:06:58 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:07:36 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:07:37 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:02 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:10:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 67
ERROR - 2019-07-08 11:10:03 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:20 --> Severity: Notice --> Undefined variable: all_info /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 68
ERROR - 2019-07-08 11:10:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/manage_property.php 68
ERROR - 2019-07-08 11:10:21 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:36 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:44 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:46 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:47 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:48 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:48 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:10:51 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:11:14 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:11:19 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:11:24 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:11:25 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 11:11:25 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 11:11:25 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 11:11:25 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 11:11:25 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-08 11:11:25 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-08 11:11:25 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-08 11:11:26 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 11:11:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 11:11:26 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 11:11:26 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-08 11:11:26 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-08 11:11:26 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-08 11:11:27 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-08 11:11:31 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-08 11:16:58 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:21:10 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:21:29 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:21:44 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:21:47 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:21:50 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:24:48 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:24:48 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:24:49 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:24:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:37:54 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /var/www/vhosts/property/httpdocs/application/models/Common_model.php 601
ERROR - 2019-07-08 11:38:28 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:38:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:38:29 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:38:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:07 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:08 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:10 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:10 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:16 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:16 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:37 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 11:39:46 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:46 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:00 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:01 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:28 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:29 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:22 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:23 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:25 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:25 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:59 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:42:00 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:42:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:42:04 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:42:04 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 11:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 12:21:58 --> Severity: Warning --> Use of undefined constant dei - assumed 'dei' (this will throw an Error in a future version of PHP) /var/www/vhosts/property/httpdocs/application/models/Common_model.php 595
ERROR - 2019-07-08 12:27:26 --> Severity: Notice --> Undefined index: all_property /var/www/vhosts/property/httpdocs/application/controllers/Listing.php 77
ERROR - 2019-07-08 12:27:41 --> Severity: Notice --> Undefined index: all_property /var/www/vhosts/property/httpdocs/application/controllers/Listing.php 77
ERROR - 2019-07-08 12:29:09 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 12:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 12:29:10 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 12:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:02:57 --> Query error: Unknown column 'propet' in 'on clause' - Invalid query: SELECT `residential_properties`.*, `property_category`.`cat_name`
FROM `residential_properties`
LEFT JOIN `property_category` ON `residential_properties`.`cat_id` = `propet`
WHERE `residential_properties`.`dealer_id` = '70'
AND `property_option` = 0
ERROR - 2019-07-08 13:03:13 --> Query error: Unknown column 'property_category' in 'on clause' - Invalid query: SELECT `residential_properties`.*, `property_category`.`cat_name`
FROM `residential_properties`
LEFT JOIN `property_category` ON `residential_properties`.`cat_id` = `property_category`
WHERE `residential_properties`.`dealer_id` = '70'
AND `property_option` = 0
ERROR - 2019-07-08 13:04:07 --> Query error: Unknown column 'property_category' in 'on clause' - Invalid query: SELECT `residential_properties`.*, `property_category`.`cat_name`
FROM `residential_properties`
LEFT JOIN `property_category` ON `residential_properties`.`cat_id` = `property_category`
WHERE `residential_properties`.`dealer_id` = '70'
AND `property_option` = 0
ERROR - 2019-07-08 13:04:48 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:04:49 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:04:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:04 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:05 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:50 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:51 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:53 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:53 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:05:59 --> Query error: Unknown column 'property_category.cat_i' in 'on clause' - Invalid query: SELECT `residential_properties`.*, `property_category`.`cat_name`
FROM `residential_properties`
JOIN `property_category` ON `residential_properties`.`cat_id` = `property_category`.`cat_i`
WHERE `residential_properties`.`dealer_id` = '70'
AND `property_option` = 0
ERROR - 2019-07-08 13:07:25 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:07:25 --> Severity: Notice --> Undefined variable: dealers /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 68
ERROR - 2019-07-08 13:11:15 --> Severity: error --> Exception: Call to undefined function number() /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 93
ERROR - 2019-07-08 13:11:45 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:11:45 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:11:45 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:11:45 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:11:45 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:05 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:05 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:05 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:05 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:05 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:12:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 105
ERROR - 2019-07-08 13:14:51 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:14:51 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:14:51 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:14:51 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:14:51 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:15:48 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 13:15:53 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 13:15:57 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 13:16:01 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 13:16:04 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 13:16:33 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 13:16:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:16:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:16:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:16:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:16:37 --> Severity: Notice --> Undefined index: dealer_status /var/www/vhosts/property/httpdocs/application/views/lists/dealerproperties.php 99
ERROR - 2019-07-08 13:16:43 --> 404 Page Not Found: Listing/fetch.php
ERROR - 2019-07-08 13:17:20 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-08 13:17:21 --> 404 Page Not Found: Js/dashboard.js
