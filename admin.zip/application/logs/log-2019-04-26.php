<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-26 13:28:49 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-26 13:30:18 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-26 13:31:21 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-04-26 13:31:21 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-04-26 13:31:21 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-04-26 13:31:21 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-04-26 13:31:21 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-04-26 13:31:21 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
