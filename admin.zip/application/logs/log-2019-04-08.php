<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-08 07:50:18 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-08 07:50:19 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:19 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-08 07:50:19 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-08 07:50:19 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-08 07:50:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-08 07:50:38 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-08 07:50:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:38 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-08 07:50:39 --> 404 Page Not Found: Js/dashboard.js
