<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-11 07:12:24 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:12:24 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:12:24 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-11 07:12:24 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-11 07:12:24 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-11 07:12:25 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 07:12:28 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 07:12:28 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 07:12:29 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:12:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:12:30 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-11 07:12:30 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-11 07:12:30 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-11 07:12:35 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:12:44 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:12:46 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:12:46 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:12:47 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:12:53 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:15:56 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:16:52 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:17:10 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:17:14 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:17:57 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:17:59 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:18:00 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:18:10 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:18:30 --> Severity: Error --> Class CI_Session_files_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) C:\xampp2\htdocs\property_dealer\system\libraries\Session\drivers\Session_files_driver.php 49
ERROR - 2019-04-11 07:21:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp2\htdocs\property_dealer\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-04-11 07:21:40 --> Unable to connect to the database
ERROR - 2019-04-11 07:23:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:23:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:23:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-11 07:23:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-11 07:23:07 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-11 07:23:07 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 07:23:07 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:23:07 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 07:23:07 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 07:23:07 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 07:23:08 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-11 07:23:08 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-11 07:23:08 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-11 07:26:15 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-11 07:26:41 --> 404 Page Not Found: Delete/size
ERROR - 2019-04-11 07:26:51 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-11 07:36:13 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-11 07:36:13 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-11 08:50:50 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-11 08:51:12 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-11 08:51:12 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-11 08:51:24 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-11 08:51:49 --> 404 Page Not Found: Edit/size
ERROR - 2019-04-11 08:51:49 --> 404 Page Not Found: Edit/size
ERROR - 2019-04-11 08:59:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 08:59:05 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-11 08:59:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 08:59:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 08:59:05 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-11 08:59:05 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-11 08:59:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-11 08:59:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 08:59:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-11 08:59:08 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-11 08:59:08 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-11 08:59:08 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-11 08:59:09 --> 404 Page Not Found: Images/faces
