<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-24 07:08:10 --> 404 Page Not Found: Images/faces
