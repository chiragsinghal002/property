<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:33:01 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:34:20 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-04-30 11:34:24 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-04-30 11:39:19 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-04-30 11:39:53 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-04-30 11:39:53 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-30 11:39:59 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-30 11:40:00 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-30 11:44:59 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-04-30 11:47:13 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 11:50:13 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 12:23:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 12:23:05 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-30 12:23:05 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-30 12:23:05 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-30 12:23:05 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-30 12:23:06 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-30 12:26:36 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
