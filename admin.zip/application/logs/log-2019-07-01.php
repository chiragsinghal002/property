<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-01 12:19:57 --> 404 Page Not Found: Vendors/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-01 12:19:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-07-01 12:19:58 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-07-01 12:20:48 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subcategory.php 33
ERROR - 2019-07-01 12:20:51 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-01 12:21:02 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-01 12:29:07 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
ERROR - 2019-07-01 12:29:07 --> Severity: Notice --> Undefined index: property_type /var/www/vhosts/property/httpdocs/application/views/lists/subchildcategory.php 50
