<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-04 07:56:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-04 07:56:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-04 07:56:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-04 07:56:16 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-04 07:56:16 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-04 07:56:16 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-04 07:56:16 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-04 07:56:17 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-04 07:56:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-04 07:56:17 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-04 07:56:17 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-04 07:56:17 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-04 07:56:18 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-04 08:13:44 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-04 08:16:23 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
ERROR - 2019-06-04 11:01:17 --> Severity: Notice --> Undefined index: property_type /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 50
