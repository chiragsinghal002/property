<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-14 04:58:51 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-14 04:58:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-14 04:58:55 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 04:59:47 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 8
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 56
ERROR - 2019-05-14 05:00:13 --> Severity: Notice --> Undefined index: area /home/logodesi/public_html/projects/property/application/views/lists/manage_property.php 57
ERROR - 2019-05-14 05:03:53 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-14 05:03:53 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-14 05:03:54 --> 404 Page Not Found: Js/dashboard.js
