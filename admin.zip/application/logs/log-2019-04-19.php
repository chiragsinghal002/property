<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-19 08:35:48 --> 404 Page Not Found: Vendors/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-19 08:35:48 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-19 08:35:48 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-19 08:35:48 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-19 08:35:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-19 08:35:49 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-19 08:35:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-19 08:35:50 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-19 08:35:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-19 08:35:50 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-19 08:35:50 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-19 08:54:14 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-19 09:00:00 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 8
ERROR - 2019-04-19 09:00:00 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
ERROR - 2019-04-19 09:00:00 --> Severity: Notice --> Undefined index: area C:\xampp2\htdocs\property_dealer\application\views\lists\manage_property.php 57
