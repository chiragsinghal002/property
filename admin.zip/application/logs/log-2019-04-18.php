<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-18 07:06:28 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-18 07:06:29 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-18 07:06:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-18 07:06:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-18 07:06:29 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-18 07:06:31 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-18 07:06:31 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-18 07:06:31 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-18 07:06:31 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-18 08:50:39 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-18 13:16:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-18 13:16:02 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-18 13:16:04 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-18 13:16:09 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-18 13:16:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-18 13:16:09 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-18 13:16:10 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-18 13:16:10 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-18 13:16:11 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-18 13:16:35 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-18 13:20:20 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\subchildcategory.php 8
ERROR - 2019-04-18 13:21:04 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
ERROR - 2019-04-18 14:11:55 --> Severity: Notice --> Undefined variable: subcategory C:\xampp2\htdocs\property_dealer\application\views\lists\unit_size.php 8
