<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-01 10:37:48 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-01 10:46:46 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-01 10:49:56 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-01 10:50:17 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-01 10:50:35 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-01 10:51:45 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-01 10:53:23 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-01 10:53:50 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
ERROR - 2019-05-01 10:54:31 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-01 11:56:11 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/unit_size.php 8
ERROR - 2019-05-01 12:24:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-01 12:24:08 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-01 12:24:09 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-01 12:24:39 --> Severity: Notice --> Undefined variable: subcategory /home/logodesi/public_html/projects/property/application/views/lists/subchildcategory.php 8
