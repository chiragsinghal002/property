<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-04 05:46:11 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/controllers/Auth.php 45
ERROR - 2019-05-04 05:46:11 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Images/faces
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Vendors/js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-05-04 05:46:12 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
ERROR - 2019-05-04 05:46:30 --> Severity: Notice --> Undefined index: dealer_name /home/logodesi/public_html/projects/property/application/views/lists/dealers.php 41
