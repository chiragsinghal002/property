<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-24 04:51:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-24 04:51:44 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-24 04:51:44 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-24 04:51:44 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-24 04:51:44 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-24 04:51:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-24 04:51:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-24 04:51:45 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-24 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'logodesi_propert'@'localhost' (using password: YES) /var/www/vhosts/property/httpdocs/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-06-24 12:30:02 --> Unable to connect to the database
