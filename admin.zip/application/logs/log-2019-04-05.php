<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-05 07:20:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-05 07:20:57 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-05 07:20:57 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-05 07:20:57 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-05 07:20:57 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-04-05 07:20:58 --> 404 Page Not Found: Vendors/js
ERROR - 2019-04-05 07:20:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-05 07:20:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-05 07:20:58 --> 404 Page Not Found: Images/faces
ERROR - 2019-04-05 07:20:58 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-04-05 07:20:58 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-04-05 07:20:58 --> 404 Page Not Found: Js/dashboard.js
