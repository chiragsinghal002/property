<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-22 10:15:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-22 10:15:30 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-22 10:15:30 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Images/faces
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Vendors/js
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Js/off-canvas.js
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Js/misc.js
ERROR - 2019-06-22 10:15:31 --> 404 Page Not Found: Js/dashboard.js
ERROR - 2019-06-22 12:08:07 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
ERROR - 2019-06-22 12:08:07 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/logodesi/public_html/projects/property/application/controllers/Dashboard.php:24) /home/logodesi/public_html/projects/property/system/libraries/Session/Session.php 143
