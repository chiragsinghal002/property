<div class="col-sm-12 footer-area">
  <div class="footer_contnt">

      <div class="col-sm-6">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="about_us.php">About Us</a></li>
                                <li><a href="#">Faq's</a></li>
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li class="last-policy"><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>


     <div class="col-sm-6">
                        <div class="footer-email">
                            <p>Copyright@2019 Yards360.com Designed & Developed By <a href="http://netmaxims.com/" target="_blank">NetMaxims</a> </p>
                        </div>
                    </div>




  

  </div>


</div>  