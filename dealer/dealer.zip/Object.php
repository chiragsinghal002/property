<?php 
	require_once 'classes/Common.php';
	require_once 'classes/Automated_mail.php';
	$common=new Common();
	$automated=new Automated_mail();
?>