<div class="input-verify">
             
   <p>A verification link has been sent to your email address.<br>
                    <span>Please click on the link to verify your email address to activate the service portal</span></p>
                </div>